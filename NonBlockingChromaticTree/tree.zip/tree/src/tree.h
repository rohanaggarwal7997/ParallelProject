#include <stdlib.h>

typedef struct node {
	int key;
	int value;
	int weight;
	node *left;
	node *right;
	node *parent;
} * tr;

// NOTE - the input to this can NOT be null!!
bool isLeaf(tr node) {
	return node->left == NULL && node->right == NULL;
}

tr search(tr root, int val) {
	tr ptr = root;

	while(true) {
		if(isLeaf(ptr)) {
			if(ptr->value == val)
				return ptr;
			else
				return NULL;
		}

		// else
		if(val <= ptr->value)
			ptr = ptr->left;
		else
			ptr = ptr->right;
	}
}

void recursiveInsert(tr root, int val) {

	if(root->left == NULL && root->right == NULL) {
		// Leaf Node Code
		if(root->value == val) return;

		/*
			Write Code Here

		*/
		tr u = (tr)malloc(sizeof(node));
		tr new_leaf = (tr)malloc(sizeof(node));
		if(root->parent->left == root)
			root->parent->left = u;
		else
			root->parent->right = u;

		u->weight = root->weight - 1;
		root->weight = 1;

		// Question - which is left and right? What is key and what is val?



	} else {
		if(root->value > val) recursiveInsert(root->left, val);
		else recursiveInsert(root->right, val);
	}
}

void insert(tr root, int val) {

	if(root == NULL) {
		root = new struct node;
		root->value = val;
	} else {
		recursiveInsert(root, val);
	}
}



tr recursiveRemove(tr root, int val) {

	if(root->left == NULL && root->right == NULL) {
		// Leaf Node Code
		if(root->value == val) {
			free(root);
			return NULL;
		} else {
			return root;
		}
		
	} else {
		if(root->value > val) root->left = recursiveRemove(root->left, val);
		else root->right = recursiveRemove(root->right, val);

		tr return_ptr = root;
		if(root->left == NULL && root->right != NULL) {		
			root->right->weight += root->weight;
			return_ptr = root->right;
		} else if(root->right == NULL && root->left != NULL) {			
			root->left->weight += root->weight;		
			return_ptr = root->left;
		}

		if(return_ptr != root)
			free(root);

		return return_ptr;
	}
}

void remove(tr root, int val) {

	if(root == NULL) {
		return;
	} else {
		recursiveRemove(root, val);
	}
}

